module FtQueryHelper
end
